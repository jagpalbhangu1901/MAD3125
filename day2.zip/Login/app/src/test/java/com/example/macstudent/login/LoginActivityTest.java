package com.example.macstudent.login;

import static org.junit.Assert.*;

public class LoginActivityTest {

}