package com.example.macstudent.grocerycart;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;

public class Add_ProductActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener{

            Spinner spnDairyProducts, spnFruits;
            TextView txtPriceperUnit, txtTotalQuantity;
            Button btnAddProducts;
            RadioButton rdoOne, rdoTwo, rdoThree, rdoFour,rdofive, rdosix, rdoSeven, rdoeight;


            String DairyProducts[] = {"Milk", "Curd", "Butter", "Ice Cream"};
            String Fruits[] = {"Apple", "Banana", "Grapes", "Orange"};



            String selectedDairyProducts, selectedFruits;

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_add__product);

                spnDairyProducts = findViewById(R.id.spnDairyProducts);
                spnDairyProducts.setOnItemSelectedListener(this);


                spnFruits = findViewById(R.id.spnFruits);
                ArrayAdapter paymentAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, Fruits);
                paymentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spnFruits.setAdapter(paymentAdapter);
                spnFruits.setOnItemSelectedListener(this);

                txtPriceperUnit = findViewById(R.id.txtPriceperUnit);
                txtTotalQuantity = findViewById(R.id.txtTotalQuantity);




                btnAddProducts = findViewById(R.id.btnAddProducts);
                btnAddProducts.setOnClickListener(this);

                rdoOne = findViewById(R.id.rdoOne);
                rdoOne.setOnClickListener(this);

                rdoTwo = findViewById(R.id.rdoTwo);
                rdoTwo.setOnClickListener(this);

                rdoThree = findViewById(R.id.rdoThree);
                rdoThree.setOnClickListener(this);

                rdoFour = findViewById(R.id.rdoFour);
                rdoFour.setOnClickListener(this);

                rdofive = findViewById(R.id.rdofive);
                rdofive.setOnClickListener(this);

                rdosix = findViewById(R.id.rdosix);
                rdosix.setOnClickListener(this);

                rdoSeven = findViewById(R.id.rdoseven);
                rdoSeven.setOnClickListener(this);

                rdoeight = findViewById(R.id.rdoeight);
                rdoeight.setOnClickListener(this);

            }

            @Override
            public void onClick(View view) {


                if (btnAddProducts.getId() == view.getId()){

                    startActivity(new Intent(getApplicationContext(), ViewOrderActivity.class));
                }
            }

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if(adapterView.getId() == spnDairyProducts.getId()){
                    selectedDairyProducts = DairyProducts[position];
                }else if(adapterView.getId() == spnFruits.getId()){
                    selectedFruits = Fruits[position];

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        }



