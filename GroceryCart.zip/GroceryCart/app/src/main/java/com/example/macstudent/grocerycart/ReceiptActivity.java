package com.example.macstudent.grocerycart;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ReceiptActivity extends AppCompatActivity {

    TextView txtPriceperUnit, txtTotalQuantity;

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), HomeActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

            SharedPreferences sp = getSharedPreferences("com.jk.login.shared", Context.MODE_PRIVATE);

            txtPriceperUnit = findViewById(R.id.txtPriceperUnit);
            txtPriceperUnit.setText(sp.getString("PriceperUnit","Data Missing"));

            txtTotalQuantity = findViewById(R.id.txtTotalQuantity);
            txtTotalQuantity.setText(sp.getString("TotalQuantity","Data Missing"));

    }
}
