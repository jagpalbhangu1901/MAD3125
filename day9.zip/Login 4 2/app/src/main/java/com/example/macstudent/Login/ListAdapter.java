package com.example.macstudent.Login;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

public class ListAdapter extends BaseAdapter {


    LayoutInflater inflater;
    Context context;
    String Event[] = {"Toronto FC", "Wiggles", "Milla", "American Animals"};
    String[] amounts = {"60","70","80","90"};
    String[] dateTime = {"12-12-2018 12:12:12 PM", "12-12-2018 13:12:12 PM",
            "12-12-2018 18:10:10 PM"};





    public ListAdapter(Context applicationContext) {
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return null;
    }
}
