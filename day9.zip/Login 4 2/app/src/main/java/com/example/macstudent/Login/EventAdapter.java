package com.example.macstudent.Login;

import android.content.Context;
import android.provider.CalendarContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.macstudent.login.R;

public class EventAdapter extends BaseAdapter {

    LayoutInflater inflater;
    Context context;
    String Event[] = {"Toronto FC", "Wiggles", "Milla", "American Animals"};
    String[] amounts = {"60","70","80","90"};
    String[] dateTime = {"12-12-2018 12:12:12 PM", "12-12-2018 13:12:12 PM",
            "12-12-2018 18:10:10 PM"};




    public EventAdapter(Context applicationContext, String[] event) {
        this.context = applicationContext;
        inflater = LayoutInflater.from(this.context);
    }

    @Override
    public int getCount() {
        return Event.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View view, ViewGroup viewGroup) {
        view = inflater.inflate(R.layout.activity_list, null);


        TextView txtDateTime = view.findViewById(R.id.txtDateTime);
        txtDateTime.setText(dateTime[position]);


        TextView txtAmount = view.findViewById(R.id.txtAmount);
        txtAmount.setText("$" + amounts[position]);


        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "item " + position + " selected", Toast.LENGTH_LONG).show();
            }
        });
        return view;
    }
}
