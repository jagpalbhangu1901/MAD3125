package com.example.macstudent.Login;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.example.macstudent.login.R;

public class ListActivity extends AppCompatActivity {

    ListView lstReport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        lstReport = findViewById(R.id.lstList);
        lstReport.setAdapter(new ListAdapter(getApplicationContext()));
    }
}

