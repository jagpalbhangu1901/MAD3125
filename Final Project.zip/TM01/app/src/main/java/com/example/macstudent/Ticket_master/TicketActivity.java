package com.example.macstudent.Ticket_master;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.macstudent.login.R;

public class TicketActivity extends AppCompatActivity {
    TextView txtDateTime, txtAmount,  txtEvent, txtName;

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), HomeActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket);


        SharedPreferences sp = getSharedPreferences("com.example.macstudent.Ticket_master.shared", Context.MODE_PRIVATE);

        txtDateTime = findViewById(R.id.txtDateTime);
        txtDateTime.setText(sp.getString("DateTime","Data Missing"));


        txtEvent = findViewById(R.id.txtEventName);
        txtEvent.setText(sp.getString("Event","Data Missing"));



        txtAmount = findViewById(R.id.txtAmount);
        txtAmount.setText(String.valueOf(sp.getInt("Amount", 0)));


        txtName = findViewById(R.id.txtName);
        txtName.setText(sp.getString("BuyerName","Data Missing"));

    }
    }

