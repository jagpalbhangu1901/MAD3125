package com.example.macstudent.Ticket_master;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.macstudent.login.R;

import java.util.Calendar;

public class UpdateProfileActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnUpdate;
    EditText edtName;
    EditText edtPhone;
    EditText edtEmail;
    EditText edtPassword;
    TextView txtDOB;
    DBHelper dbHelper;
    SQLiteDatabase Ticket_MasterDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);



        btnUpdate = findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(this);

        edtName = findViewById(R.id.edtName);
        edtPhone = findViewById(R.id.edtPhone);
        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);

        txtDOB = findViewById(R.id.txtDOB);
        txtDOB.setOnClickListener(this);

        dbHelper = new DBHelper(this);

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnUpdate.getId()){
            String data = edtName.getText().toString() + "\n" + edtPhone.getText().toString() +
                    "\n" + edtEmail.getText().toString() + "\n" + edtPassword.getText().toString();

            Toast.makeText(this, data, Toast.LENGTH_LONG).show();

//            Intent loginIntent = new Intent(this, LoginActivity.class);
//            startActivity(loginIntent);

            startActivity(new Intent(this,LoginActivity.class));

            insertData();
        }else if(view.getId() == txtDOB.getId()){
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(this, datePickerListener, calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        }
    }


    DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
            String DOB = String.valueOf(month+1) + "/" + String.valueOf(day) + "/" + String.valueOf(year);
            txtDOB.setText(DOB);
        }
    };

    private void insertData(){
        String name = edtName.getText().toString();
        String Phone = edtPhone.getText().toString();
        String Email = edtEmail.getText().toString();
        String Password = edtPassword.getText().toString();
        String DOB = txtDOB.getText().toString();


        ContentValues cv = new ContentValues();
        cv.put("Name",name);
        cv.put("Email", Email);
        cv.put("Phone",Phone);
        cv.put("Password",Password);
        cv.put("DOB",DOB);

        try{
            Ticket_MasterDB = dbHelper.getWritableDatabase();
            Ticket_MasterDB.insert("UserInfo", null, cv);
            Log.v("UpdateProfileActivity", "Account Details Updated");

        }catch(Exception e){
            Log.e( "UpdateProfileActivity", e.getMessage());

        }

        Ticket_MasterDB.close();
    }
    private void displayData(){
        try{
            Ticket_MasterDB = dbHelper.getReadableDatabase();
            String columns[] ={"Name","Phone","Email","Password","DOB"};

            Cursor cursor = Ticket_MasterDB.query("UserInfo",columns, null,null,null,null,null);

            while(cursor.moveToNext()){
                String UserData = cursor.getString(cursor.getColumnIndex( "Name "));
                UserData += "\n" +cursor.getString(cursor.getColumnIndex( "Phone "));
                UserData += "\n" +cursor.getString(cursor.getColumnIndex( "Email"));
                UserData += "\n" +cursor.getString(cursor.getColumnIndex( "Password"));
                UserData += "\n" +cursor.getString(cursor.getColumnIndex( "DOB "));

                Toast.makeText(this,UserData,Toast.LENGTH_LONG).show();
            }

        }catch (Exception e){
            Log.e("UpdateProfileActivity", e.getMessage());
        }
    }
}

