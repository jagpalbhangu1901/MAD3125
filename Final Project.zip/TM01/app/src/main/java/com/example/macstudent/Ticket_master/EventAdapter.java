package com.example.macstudent.Ticket_master;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.macstudent.login.R;

public class EventAdapter extends BaseAdapter {
    String[] Event;
    int[] Logos;
    Context context;
    LayoutInflater inflater;

    EventAdapter(Context context, String[] Event, int[] logos) {
        this.Logos = logos;
        this.Event = Event;
        this.context = context;
        inflater = LayoutInflater.from(context);

    }


    @Override
    public int getCount() {
        return Event.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.event_spinner_item, null);

        ImageView imgLogo =(ImageView) convertView.findViewById(R.id.imgLogo);
        TextView txtEvent = convertView.findViewById(R.id.txtEvent);

        imgLogo.setImageResource(this.Logos[position]);
        txtEvent.setText(this.Event[position]);


        return convertView;
    }
}
