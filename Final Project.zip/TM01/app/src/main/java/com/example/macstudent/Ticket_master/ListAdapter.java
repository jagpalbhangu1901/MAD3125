package com.example.macstudent.Ticket_master;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.macstudent.login.R;

public class ListAdapter extends BaseAdapter {

    LayoutInflater inflater;
    Context context;
    String Event[] = {"Toronto FC", "Wiggles", "Milla", "American Animals"};
    String[] amounts = {"60","70","80","90"};
    String[] DateTime = {"12-12-2018 12:12:12 PM", "12-12-2018 13:12:12 PM",
            "12-12-2018 18:10:10 PM"};

    public ListAdapter(Context applicationContext) {
        this.context = applicationContext;
        inflater = LayoutInflater.from(this.context);
    }

    @Override
    public int getCount() {
        return Event.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View view, ViewGroup viewGroup) {

        view =inflater.inflate(R.layout.list_items,null);

        TextView txtDateTime = view.findViewById(R.id.txtDateTime);
        txtDateTime.setText(position);


        TextView txtEvent = view.findViewById(R.id.txtEvent);
        txtEvent.setText(Event[position]);

        TextView txtAmount= view.findViewById(R.id.txtAmount);
        txtAmount.setText("$" + amounts[position]);


        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context,"item" + position +"selected", Toast.LENGTH_LONG).show();
            }
        });
        return view;
    }
}
