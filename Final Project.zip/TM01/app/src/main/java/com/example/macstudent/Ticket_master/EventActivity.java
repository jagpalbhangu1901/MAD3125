package com.example.macstudent.Ticket_master;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.macstudent.login.R;

public class EventActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);


    }
}
