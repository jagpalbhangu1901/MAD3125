package com.example.macstudent.login;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.macstudent.login.R;

public class ReportAdapter extends BaseAdapter {

    LayoutInflater inflater;
    Context context;
    String[] CarPlates = {"ASF123","QWE321","ASDF123"};
    String[] Amount = {"10","20","50"};
    String[] Lots = {"A","B","C"};
    String[] Spots ={"1","41","23"};
    String[] DateTime ={"12-12-2017 12:12:12 PM","10-02-2018 11:03:06 PM","21-02-2018 03:02:45 PM"};

    ReportAdapter(Context context){
        this.context = context;
        inflater = LayoutInflater.from(this.context);

    }



    @Override
    public int getCount() {
        return CarPlates.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View view, ViewGroup viewGroup) {

        view =inflater.inflate(R.layout.list_report_item,null);

        TextView txtDateTime = view.findViewById(R.id.txtDateTime);
        txtDateTime.setText(DateTime[position]);

        TextView txtCarPlates = view.findViewById(R.id.txtCarPlate);
        txtCarPlates.setText(CarPlates[position]);

        TextView txtAmount= view.findViewById(R.id.txtAmount);
        txtAmount.setText("$" + Amount[position]);

        TextView txtLots = view.findViewById(R.id.txtLot);
        txtLots.setText("Lot : " + Lots [position]);


        TextView txtSpot = view.findViewById(R.id.txtSpot);
        txtSpot.setText("Spot : " + Spots[position]);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context,"item" + position +"selected", Toast.LENGTH_LONG).show();
            }
        });
        return view;
    }
}
