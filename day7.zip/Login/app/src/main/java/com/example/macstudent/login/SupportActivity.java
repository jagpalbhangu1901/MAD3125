package com.example.macstudent.login;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

public class SupportActivity extends AppCompatActivity {

    Button btnEmail;
    Button btnCall;
    Button btnSMS;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);

        btnCall = findViewById(R.id.btnCall);
        btnCall.setOnClickListener(this);

        btnSMS = findViewById(R.id.btnSms);
        btnSMS.setOnClickListener(this);

        btnEmail = findViewById(R.id.btnEmail);
        btnEmail.setOnClickListener(this);
    }



    @Override
    public void onClickView(View view) {
         switch (view.getId()){
             case R.id.btnCall:
                break;
             case R.id.btnSms:
                break;
             case R.id.btnEmail:
                break;

            }
        }

        private void makeCall(){
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:1234567890"));

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(),"Call Permission Denied",Toast.LENGTH_SHORT).show();
            return;


            startActivity(callIntent);
        }

        private void sendSms(){
                Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto: 1234567890"));
                smsIntent.putExtra("sms_body","Tt");

                if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(getApplicationContext(),"Call Permission Denied",Toast.LENGTH_SHORT).show();
                    return;

            }

                startActivity(smsIntent);
        }
        private void sendEmail(){
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                emailIntent.putExtra(Intent.EXTRA_EMAIL,
                        new String[]{"jagpalbhangu1@gmail.com","preetamanpannu1195@gmail.com"});
                emailIntent.putExtra(Intent.EXTRA_SUBJECT,"TEST EMAIL");
                emailIntent.putExtra(Intent.EXTRA_TEXT,"This is test Message");

                emailIntent.setType("*/*");

                startActivity();

                        }
            }






