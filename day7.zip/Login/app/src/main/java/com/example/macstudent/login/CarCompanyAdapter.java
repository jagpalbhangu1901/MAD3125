package com.example.macstudent.login;

import android.content.Context;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CarCompanyAdapter extends BaseAdapter {
    int[] logos;
    String[] companyNames;
    Context context;
    LayoutInflater inflater;
    CarCompanyAdapter(Context context, int[] logos, String[] companyNames) {

        this.logos = logos;
        this.companyNames = companyNames;
        this.context = context;
        inflater = LayoutInflater.from(context);

    }
    @Override
    public int getCount() {
        return companyNames.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.carcompany_spinner_item, null);

        ImageView imglogo = convertView.findViewById(R.id.imglogo);
        TextView txtcompany= convertView.findViewById(R.id.txtcompany);

        imglogo.setImageResource(this.logos[position]);
        txtcompany.setText(this.companyNames[position]);

        return convertView;
    }
}
