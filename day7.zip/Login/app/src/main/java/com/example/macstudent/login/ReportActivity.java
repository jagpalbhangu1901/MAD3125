package com.example.macstudent.login;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class ReportActivity extends AppCompatActivity {

    ListView lstReport;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        lstReport = findViewById(R.id.lstReport);
        lstReport.setAdapter(new ReportAdapter(getApplicationContext()));
    }
}
