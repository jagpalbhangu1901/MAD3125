package com.example.macstudent.Login;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Spinner;

import com.example.macstudent.login.R;

public class New_eventActivity extends AppCompatActivity {

    Spinner spnEvents,spnPayment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event);


    }
}
