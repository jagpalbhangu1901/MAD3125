package com.example.macstudent.Ticket_master;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;


import com.example.macstudent.login.R;

import java.util.Calendar;


    public class NewEventActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

        Spinner spnEvents,spnPayment;
        TextView txtAmount, txtDateTime ;
        EditText edtEnterEventsName;
        Button btnConfirm_Tickets;
        RadioButton rdoOne, rdoTwo, rdoThree, rdoFour;

        int Ticketprice[] = {60,70,80,90};
        String payment[] = {"Debit Card", "Credit Card", "Master Card", "American Express", "Cash"};
        String Event[] = {"Toronto FC", "Wiggles", "Milla", "American Animals"};

        String selectedPayment, selectedEvents;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_new_event);



            // spnEvents = findViewById(R.id.spnEvents);
            // EventAdapter EventAdapter = new EventAdapter(getApplicationContext(), Event);
            // spnEvents.setAdapter(EventAdapter);
            //  spnEvents.setOnItemSelectedListener(this);


            spnPayment = findViewById(R.id.spnPayment);
            ArrayAdapter paymentAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, payment);
            paymentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spnPayment.setAdapter(paymentAdapter);
            spnPayment.setOnItemSelectedListener(this);

            txtAmount = findViewById(R.id.txtAmount);
            txtDateTime = findViewById(R.id.txtDateTime);
            txtDateTime.setText(Calendar.getInstance().getTime().toString());

            edtEnterEventsName = findViewById(R.id.edtEnterEventsName);

            btnConfirm_Tickets = findViewById(R.id.btnConfirmTicket);
            btnConfirm_Tickets.setOnClickListener(this);

            rdoOne = findViewById(R.id.rdoOne);
            rdoOne.setOnClickListener(this);

            rdoTwo = findViewById(R.id.rdoTwo);
            rdoTwo.setOnClickListener(this);

            rdoThree = findViewById(R.id.rdoThree);
            rdoThree.setOnClickListener(this);

            rdoFour = findViewById(R.id.rdoFour);
            rdoFour.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if(rdoOne.isChecked()){
                txtAmount.setText("$" + Ticketprice[0]);
            }else if (rdoTwo.isChecked()){
                txtAmount.setText("$" + Ticketprice[1]);
            }else if (rdoThree.isChecked()){
                txtAmount.setText("$" + Ticketprice[2]);
            }else if (rdoFour.isChecked()){
                txtAmount.setText("$" + Ticketprice[3]);
            }

            if (btnConfirm_Tickets.getId() == view.getId()){
                SharedPreferences sp = getSharedPreferences("com.example.macstudent.login.shared", Context.MODE_PRIVATE);
                SharedPreferences.Editor edit = sp.edit();

                edit.putString("EventName",edtEnterEventsName.getText().toString());
                edit.putString("Event", selectedEvents);
                edit.putString("Payment",selectedPayment);
                edit.putString("DateTime",txtDateTime.getText().toString());
                edit.putInt("Amount", Integer.parseInt(txtAmount.getText().toString().substring(1)));

                edit.commit();

                startActivity(new Intent(getApplicationContext(), TicketActivity.class));
            }
        }

        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
//        if(adapterView.getId() == spnEvents.getId()){
//            selectedEvents = Event[position];
//        }else
            if(adapterView.getId() == spnPayment.getId()){
                selectedPayment = payment[position];
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {

        }
    }

